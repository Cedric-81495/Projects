# Handcuffs 2 Cufflinks — API

Express + TypeScript + MongoDB (Mongoose) backend for the H2C platform.
Implements the exact contract the frontend (`h2c-web`) is already wired to, so
connecting the two is just setting env vars.

## Stack & security
Express 4 · Mongoose 8 · Zod validation · TypeScript (ESM, NodeNext).
Hardening: Helmet, CORS allow-list, JSON body limit (100 kb), rate limiting on
writes, compression, request logging, centralized error handler, `/health`.

---

## Quick start

```bash
npm install
cp .env.example .env        # then fill in MONGODB_URI + CORS_ORIGIN
npm run seed                # populate stories / episodes / tracks
npm run dev                 # http://localhost:4000  (tsx watch)
```

Build & run for production:

```bash
npm run build               # tsc → dist/
npm start                   # node dist/index.js
```

`npm run typecheck` runs types only.

---

## Environment

| Var           | Required | Notes                                                         |
| ------------- | -------- | ------------------------------------------------------------- |
| `MONGODB_URI` | ✅        | Atlas connection string. **Backend only — never in the frontend.** |
| `CORS_ORIGIN` | ✅        | Comma-separated browser origins (local + deployed frontend).  |
| `PORT`        |          | Defaults to `4000` (Render sets this automatically).          |
| `NODE_ENV`    |          | `production` on Render.                                        |

The process **validates env at startup and exits** if `MONGODB_URI` is missing.

---

## Endpoints (matches the frontend service layer)

Base path: `/api`. All errors return `{ message }`.

| Method & path              | Body                                    | Returns                    |
| -------------------------- | --------------------------------------- | -------------------------- |
| `GET  /health`             | —                                       | `{ status, uptime }`       |
| `POST /api/newsletter`     | `{ email, source? }`                    | `201 { ok: true }` (idempotent) |
| `POST /api/members`        | `{ name, email, interests[] }`          | `201 { ok: true }` (upsert)|
| `POST /api/community/stories` | `{ name, email, title, story }`      | `201 { ok: true }` (status `pending`) |
| `GET  /api/stories`        | —                                       | `{ data: Story[] }`        |
| `GET  /api/episodes`       | —                                       | `{ data: Episode[] }`      |
| `GET  /api/tracks`         | —                                       | `{ data: Track[] }`        |

GET items use `id` (from the document `slug`) to match the frontend types exactly.
Community submissions are stored as **`pending`** and never returned publicly until
approved (moderation is the next phase — see `memory.md` in `h2c-web`).

---

## MongoDB Atlas setup
1. Create a free cluster at mongodb.com/atlas.
2. Database Access → add a user (username + password).
3. Network Access → allow your IP for local dev; for Render add `0.0.0.0/0`
   (Render egress IPs are dynamic on the free tier) or Render's static IPs on paid.
4. Connect → Drivers → copy the URI; insert the DB name (e.g. `/h2c`) and your
   password. Put it in `.env` (local) and in Render's env (deploy).

## Deploy to Render (web service)
Commit `render.yaml` (Blueprint) **or** set in the dashboard:

| Setting          | Value                     |
| ---------------- | ------------------------- |
| Type             | **Web Service** (Node)    |
| Build Command    | `npm ci && npm run build` |
| Start Command    | `npm start`               |
| Health Check Path| `/health`                 |
| Env vars         | `MONGODB_URI`, `CORS_ORIGIN`, `NODE_ENV=production` |

After deploy, set the frontend's `VITE_API_URL` to
`https://<this-service>.onrender.com/api` and redeploy the frontend. Run the seed
once from your machine (pointing `MONGODB_URI` at Atlas) or add a one-off job.

---

## Project layout
```
src/
├── config/env.ts         validated environment
├── db/connect.ts         mongoose connect / disconnect
├── models/               Newsletter, Member, CommunityStory, Story, Episode, Track
├── validation/schemas.ts zod request schemas
├── middleware/           validate, errorHandler (+ HttpError), notFound, asyncHandler
├── routes/               newsletter, members, community, content, index (mounts /api)
├── seed/seed.ts          content seeding
├── app.ts                express app + security middleware
└── index.ts              startup + graceful shutdown
```

---

## Admin auth & endpoints (Phase 3)

Single-admin auth via env (`ADMIN_EMAIL` + bcrypt `ADMIN_PASSWORD_HASH`), issued
as a **JWT in an httpOnly cookie**. No admin user is stored in the DB.

Setup:
```bash
npm run hash -- "your-strong-password"   # paste output into ADMIN_PASSWORD_HASH
# set ADMIN_EMAIL and a long JWT_SECRET too
```

CORS runs with `credentials: true`; the frontend must call with `credentials: 'include'`.
For a cross-domain deploy (frontend and API on different hosts) cookies are set
`SameSite=None; Secure`, which requires HTTPS (Render provides it).

| Method & path                          | Auth  | Purpose                              |
| -------------------------------------- | ----- | ------------------------------------ |
| `POST /api/admin/login`                | —     | `{ email, password }` → sets cookie  |
| `POST /api/admin/logout`               | —     | clears cookie                        |
| `GET  /api/admin/me`                   | admin | current admin identity               |
| `GET  /api/admin/community/stories?status=pending` | admin | list submissions          |
| `PATCH /api/admin/community/stories/:id` | admin | `{ status: 'approved'|'rejected' }` |
| `GET/POST /api/admin/stories`          | admin | list / create story                 |
| `PATCH/DELETE /api/admin/stories/:id`  | admin | update / delete story               |
| `…/episodes`, `…/tracks`               | admin | same CRUD shape                      |
| `GET /api/community/stories`           | —     | public gallery (approved only)       |

Login is rate-limited (10 / 15 min). Community submissions land as `pending` and
are invisible publicly until an admin approves them.
