# Handcuffs 2 Cufflinks — Frontend

A production React + TypeScript + Tailwind frontend for the **Movement‑Driven Brand
Ecosystem Platform**. The site is organized around the movement's domains, not generic
pages, and guides the visitor through one emotional arc: *from struggle to success*.

Palette: black + gold (brass) + forest green — the "handcuffs → cufflinks" arc, grounded
in a Boston‑night key art.

## Stack

- **Vite 5** + **React 18** + **TypeScript** (strict)
- **Tailwind CSS 3** with brand tokens, plus a hand‑authored design layer for the
  per‑section "arc" surfaces that pure utilities can't express cleanly
- **React Router 6** (SPA)
- No backend required to run — content is served from a typed local data layer that is
  ready to swap for API calls (see *Wiring the backend*).

## Getting started

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # type‑checks then builds to dist/
npm run preview    # serve the production build
npm run typecheck  # tsc --noEmit
npm run lint       # eslint
```

## Project structure

The tree mirrors the client's mental model — functional hubs, not e‑commerce pages.

```
src/
├── modules/                 # domain hubs
│   ├── home/                # the homepage journey (Hero → … → Join)
│   │   └── sections/        # each stop on the arc
│   ├── movement/            # mission hub
│   ├── storytelling/        # docuseries library
│   ├── media/
│   │   ├── podcast/         # conversation hub
│   │   └── music/           # Kitchen Muzik (creative hub)
│   ├── apparel/             # shop, product, shop-the-look (brand expression)
│   ├── ecosystem/           # GWOP
│   ├── founder/             # authority hub + FAQ
│   ├── community/           # participation hub + story form
│   ├── join/                # engagement hub + form
│   └── legal/
├── components/              # global chrome (header, footer, overlays)
├── layouts/                 # RootLayout (chrome + <Outlet/>)
├── shared/                  # UI atoms, Cart + UI context, nav config
├── services/                # content service — the backend seam
├── data/                    # typed content ("the blocks the team edits")
├── types/                   # domain contracts
├── lib/                     # cn, money, useReveal
├── styles/                  # global.css (tokens + arc system + components)
└── assets/ (public/assets)  # real photography + key art + logo
```

## The design system

- **Tokens** live in `src/styles/global.css` (`:root`) and `tailwind.config.ts`.
- **The arc**: every `<section>` carries a tone class (`t-0` … `t-7`, `t-light`,
  `t-paper`) that sets `--surface`, `--fg`, `--accent` for that band. As you scroll the
  page warms from cold steel toward brass — the visual thesis of the brand.
- **Type**: Big Shoulders Display (display), Newsreader (story serif), Archivo (UI).
- Reduced motion, keyboard focus, and mobile layouts are handled at the base level.

## Wiring the backend (MERN)

Every component reads content through `src/services/content.ts`. Today those functions
return the typed local data; to connect the Express/Mongo API, change only the function
bodies — component code is untouched:

```ts
export const getProducts = () => http<Product[]>('/products');
```

`http<T>()` already points at `VITE_API_BASE` (default `/api`) and sends credentials.
Form submissions (`submitStory`, `submitJoin`) are stubbed and ready to POST.

The cart (`shared/CartContext`) is a client reducer; swap `checkout` for a call to your
orders/payment endpoint when the backend lands.

### Suggested API surface

```
GET  /api/products            GET  /api/products/:id
GET  /api/collections         GET  /api/looks
GET  /api/episodes            GET  /api/podcast
GET  /api/music               GET  /api/faq
GET  /api/community/stories   POST /api/community/stories
POST /api/join                POST /api/orders
```

## Deployment

Static SPA — deploy `dist/` to any static host. SPA fallback rewrites are included for
Netlify (`public/_redirects`) and Vercel (`vercel.json`). Set `VITE_API_BASE` to your API
origin at build time.

## Notes on the content

All copy, prices, guest details, and release titles are placeholders pending the founder's
real information, and every image is the reference key art / photoshoot supplied in the
prototype. Replace `public/assets/*` with production images (add `srcset`) before launch.
